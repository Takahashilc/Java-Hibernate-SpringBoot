package pilha.java;

public class MinhaException extends Exception {
	public MinhaException(String msg) {
		super(msg);
	}
}
