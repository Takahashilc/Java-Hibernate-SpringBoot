package bytebank.herdade.conta;

public interface Tributavel {
	
	double getValorImposto();

}
