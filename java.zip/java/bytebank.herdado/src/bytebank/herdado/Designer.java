package bytebank.herdado;

public class Designer extends Funcionario{
	
	public double getBonificacao() {
		return 200;
	}
	
	
}
