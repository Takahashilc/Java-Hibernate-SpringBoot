package pilha.java;

public class Conta {
	void deposita() throws MinhaException{
		
	}
}
