/**
 * 
 */
/**
 * @author leand
 *
 */
module bytebank.encapsulado {
}