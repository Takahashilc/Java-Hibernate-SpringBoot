package sintaxe.variaveis.e.fluxo;

public class TestaVariaveis {

	public static void main(String[] args) {
		System.out.println("ola novo teste");
		
		int idade;
		idade = 37;
		System.out.println(idade);
		
		idade = 30+10;
		System.out.println(idade);
		idade = 7 * 5 + 2; 
		System.out.println(idade);
		
		System.out.println("a idade é " + idade + " , Parabens!");
	}
}
