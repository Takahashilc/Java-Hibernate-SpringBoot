/**
 * 
 */
/**
 * @author leand
 *
 */
module sintaxebasica {
}