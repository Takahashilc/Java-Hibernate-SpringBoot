/**
 * 
 */
/**
 * @author leand
 *
 */
module bytebank.herdade.conta {
}