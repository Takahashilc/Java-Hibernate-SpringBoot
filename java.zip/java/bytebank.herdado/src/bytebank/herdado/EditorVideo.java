package bytebank.herdado;

public class EditorVideo extends Funcionario{
	
	public double getBonificacao() {
		return 150;
	}
	
	
}
