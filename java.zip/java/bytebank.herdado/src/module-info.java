/**
 * 
 */
/**
 * @author leand
 *
 */
module bytebank.herdado {
}