/**
 * 
 */
/**
 * @author leand
 *
 */
module bytebank.composto {
}